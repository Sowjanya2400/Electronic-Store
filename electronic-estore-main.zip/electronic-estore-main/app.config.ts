const appConfig = {
  name: "Electronics Store",
  logo: "/img/logo.webp",
}

export default appConfig
