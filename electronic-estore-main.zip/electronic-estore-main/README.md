# EKART APPLICATION

## Commands

- `npm install` - Install dependencies
- `npm run dev` - Run development server

## Credentials

### Admin

- Email: `admin@ekart.com`
- Password: `adminaccount`

### Customer

- Email: `customer@ekart.com`
- Password: `customeraccount`
